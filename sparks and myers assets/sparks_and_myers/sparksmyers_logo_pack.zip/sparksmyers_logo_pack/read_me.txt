9G Design - Creative services company
T : 01843 581924
E : ask@9gdesign.co.uk
W : www.9gdesign.co.uk

This logo was designed and output by 9G Design, if you need any assistance with this logo please 
contact us directly

File types explained:

AI CS2 - master: The original logo file with original text.
AI CS2 - Logo: A copy of the original with outlined text. The text in this file cannot be changed.

TT Files : These are the specified fonts in the logo.

JPEG: High resolution images.


Most used file:

EPS: This file can be used with almost any design company or print house. Eps files can be read by most
     of todays design/ print software.

PDF: Viewed in Adobe Acrobat reader, some printers will only accept HI-resolution PDF files.